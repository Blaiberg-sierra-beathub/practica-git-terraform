"""Lógica de negocio (PLANTILLA: completa cada función siguiendo la guía, sección 5 y 8.7).

Los nombres de funciones y helpers son los mismos que en la guía. Orden de trabajo:
  _code -> prepare_finance -> prepare_catalogs -> _catalog -> build_transacciones
"""

from pyspark.sql import DataFrame, Window, functions as F

from schema import CATALOG_SOURCE_COLUMNS, FINANCE_SOURCE_SCHEMA
from utils import add_row_hash

TABLE = "TODO_nombre_tabla_silver"

# TODO (guía 8.6): columnas de negocio de la tabla, en el MISMO orden que columns_ddl en schema.py.
# Referencia: transaction_id, transaction_ts, transaction_type, account_code, account_name,
# account_category, cost_center_code, cost_center_name, currency_code, currency_name,
# rate_to_cop, amount, amount_signed, amount_cop, description
BUSINESS_COLUMNS = []


def _require_columns(df: DataFrame, expected: list, input_name: str) -> None:
    """Ya implementado: valida que la entrada traiga las columnas esperadas."""
    missing = sorted(set(expected) - set(df.columns))
    if missing:
        raise ValueError(f"La entrada {input_name} no trae las columnas {missing}.")


def _code(column: str):
    """TODO (guía 5.1): texto sin espacios y en mayúsculas (F.upper, F.trim)."""
    raise NotImplementedError("TODO: implementa _code (guía 5.1)")


def prepare_finance(finance_raw: DataFrame) -> DataFrame:
    """TODO (guía 5.1): valida con _require_columns y tipa/normaliza las columnas de transacciones."""
    raise NotImplementedError("TODO: implementa prepare_finance (guía 5.1)")


def prepare_catalogs(catalogs_raw: DataFrame) -> DataFrame:
    """TODO (guía 5.2): solo filas activas y un registro por código (Window + row_number)."""
    raise NotImplementedError("TODO: implementa prepare_catalogs (guía 5.2)")


def _catalog(catalogs: DataFrame, catalog_type: str, key: str, renames: dict) -> DataFrame:
    """TODO (guía 5.3): filtra por catalog_type y renombra columnas para el join."""
    raise NotImplementedError("TODO: implementa _catalog (guía 5.3)")


def build_transacciones(finance: DataFrame, catalogs: DataFrame) -> DataFrame:
    """TODO (guías 5.3 a 5.6): LEFT JOIN con cuentas, centros de costo y monedas (broadcast),
    signo contable, conversión a pesos, process_date, row_hash y select final con dropDuplicates."""
    raise NotImplementedError("TODO: implementa build_transacciones (guías 5.3 a 5.6)")


def build_silver_tables(finance_raw: DataFrame, catalogs_raw: DataFrame) -> dict:
    """Ya implementado. Claves = nombres de tabla Iceberg (iguales a schema.SILVER_TABLES)."""
    return {TABLE: build_transacciones(prepare_finance(finance_raw), prepare_catalogs(catalogs_raw))}
