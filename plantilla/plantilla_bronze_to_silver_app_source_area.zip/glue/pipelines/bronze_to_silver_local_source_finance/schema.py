"""Contrato del pipeline (PLANTILLA: completa los TODO siguiendo la guía, sección 8).

Entradas (Bronze, fuente local-source):
  - entity=finance/   Parquet con transacciones financieras ficticias.
  - entity=catalogs/  CSV de catálogos con la cabecera catalog_type,code,name,category,rate_to_cop,active.
"""

from pyspark.sql.types import (
    DecimalType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

# Columnas que debe traer el Parquet de entity=finance/ (contrato de la fuente).
FINANCE_SOURCE_SCHEMA = StructType([
    StructField("transaction_id", StringType()),
    StructField("transaction_ts", TimestampType()),
    StructField("account_code", StringType()),
    StructField("cost_center_code", StringType()),
    StructField("currency_code", StringType()),
    StructField("amount", DecimalType(18, 2)),
    StructField("transaction_type", StringType()),
    StructField("description", StringType()),
])

# Cabecera de los CSV de entity=catalogs/ (todo texto).
CATALOG_SOURCE_COLUMNS = ["catalog_type", "code", "name", "category", "rate_to_cop", "active"]

TABLE_DDL = {
    "TODO_nombre_tabla_silver": {
        "database_key": "silver_database",
        # TODO: lista las columnas de tu tabla Silver, con su tipo, separadas por comas.
        "columns_ddl": """
        """,
        "partition_expr": "TODO",   # TODO: por ejemplo months(process_date)
        "match_columns": [],         # TODO: clave del MERGE (columnas que identifican cada fila)
    },
}

SILVER_TABLES = [
    "TODO_nombre_tabla_silver",
]
