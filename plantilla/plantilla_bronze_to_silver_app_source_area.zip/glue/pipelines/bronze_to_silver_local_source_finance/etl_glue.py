"""Glue Job DUMMY del pipeline bronze_to_silver_local_source_finance (ejercicio de
formación): Bronze (Parquet + CSV) → Silver (Iceberg), con Data Quality bloqueante,
escritura idempotente por hash de contenido y verificación de escritura.

Entradas (config.json): `finance` (Parquet de transacciones) y `catalogs` (CSV de
catálogos). Se cruzan en business_logic.py. Como parquet/csv no usan Glue
Bookmarks, cada ejecución relee la ventana completa; el MERGE por row_hash hace
que releer no duplique.

Este entrypoint concentra los Job Arguments y la orquestación (leer → transformar
→ validar → escribir → verificar). La lógica de negocio vive en business_logic.py.
El config.json define QUÉ se procesa (agnóstico); Terraform inyecta el DÓNDE como
Job Arguments (PlatformBinding, modelo B2-a).
"""

import sys
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

import boto3
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from business_logic import build_silver_tables
from quality import evaluate_table_quality, load_quality_config
from schema import SILVER_TABLES, TABLE_DDL
from utils import (
    PlatformBinding,
    build_spark_session,
    configure_logging,
    load_and_validate_pipeline_config,
    parse_s3_uri,
    read_inputs,
    read_json_from_s3,
    write_json_to_s3,
    write_outputs,
)

import logging

logger = logging.getLogger("etl_glue")

# Formatos de entrada que la lógica de este pipeline sabe transformar.
PIPELINE_INPUT_FORMATS = ("parquet", "csv")

# Nombres lógicos de las entradas en config.json.
FINANCE_INPUT = "finance"
CATALOGS_INPUT = "catalogs"


REQUIRED_ARGS = [
    "JOB_NAME", "environment", "pipeline_name", "pipeline_config_s3_uri",
    "quality_rules_s3_uri", "quality_results_bucket",
    # Binding de plataforma (el "donde"): lo inyecta Terraform.
    "catalog_name", "silver_warehouse", "silver_database", "bronze_bucket",
]

OPTIONAL_ARGS_DEFAULTS = {
    "log_level": "INFO",
    "max_retry_attempts": "5",
    "retry_base_delay_seconds": "1.0",
    "source_prefix": "",
    # Modo de ventana de lectura de Bronze. Los archivos de este ejercicio se cargan
    # a mano en particiones day= (sin hour=) y con fecha fija: "full" lee todo el
    # prefijo de cada entidad. Se puede forzar otro con --bronze_window_mode.
    "bronze_window_mode": "full",
}


@dataclass(frozen=True)
class JobConfig:
    job_name: str
    environment: str
    pipeline_name: str
    pipeline_config_s3_uri: str
    quality_rules_s3_uri: str
    quality_results_bucket: str
    log_level: str
    max_retry_attempts: int
    retry_base_delay_seconds: float
    catalog_name: str
    silver_warehouse: str
    silver_database: str
    bronze_bucket: str
    source_prefix: str
    bronze_window_mode: str


def load_job_config(argv) -> JobConfig:
    # getResolvedOptions exige todo argumento que se le pida: solo se piden los
    # opcionales presentes en la invocación; el resto toma su valor por defecto.
    present = [k for k in OPTIONAL_ARGS_DEFAULTS
               if any(a == f"--{k}" or a.startswith(f"--{k}=") for a in argv)]
    resolved = getResolvedOptions(argv, REQUIRED_ARGS + present)
    for key, default in OPTIONAL_ARGS_DEFAULTS.items():
        resolved.setdefault(key, default)

    return JobConfig(
        job_name=resolved["JOB_NAME"],
        environment=resolved["environment"],
        pipeline_name=resolved["pipeline_name"],
        pipeline_config_s3_uri=resolved["pipeline_config_s3_uri"],
        quality_rules_s3_uri=resolved["quality_rules_s3_uri"],
        quality_results_bucket=resolved["quality_results_bucket"],
        log_level=resolved["log_level"],
        max_retry_attempts=int(resolved["max_retry_attempts"]),
        retry_base_delay_seconds=float(resolved["retry_base_delay_seconds"]),
        catalog_name=resolved["catalog_name"],
        silver_warehouse=resolved["silver_warehouse"],
        silver_database=resolved["silver_database"],
        bronze_bucket=resolved["bronze_bucket"],
        source_prefix=resolved["source_prefix"],
        bronze_window_mode=resolved["bronze_window_mode"],
    )


def platform_binding(config: "JobConfig") -> PlatformBinding:
    return PlatformBinding(
        catalog_name=config.catalog_name,
        silver_warehouse=config.silver_warehouse,
        silver_database=config.silver_database,
        bronze_bucket=config.bronze_bucket,
        source_prefix=config.source_prefix,
        bronze_window_mode=config.bronze_window_mode,
    )


def _assert_session_warehouse(spark, flow: dict) -> None:
    """El warehouse es config estática (--conf, lo pone Terraform). Si el
    config.json cambió sin re-aplicar Terraform, la sesión tendría otro
    warehouse: se aborta."""
    key = f"spark.sql.catalog.{flow['catalog_name']}.warehouse"
    session_value = spark.conf.get(key, "")
    if session_value.rstrip("/") != flow["warehouse"].rstrip("/"):
        raise ValueError(
            f"{key}='{session_value}' no coincide con config.json ('{flow['warehouse']}'). "
            "Re-aplicar Terraform del pipeline."
        )


def main() -> None:
    config = load_job_config(sys.argv)
    configure_logging(config.log_level)

    execution_id = str(uuid.uuid4())
    execution_timestamp = datetime.now(timezone.utc).isoformat()

    logger.info("=" * 70)
    logger.info("INICIO PIPELINE %s | job=%s | env=%s | execution_id=%s",
                config.pipeline_name, config.job_name, config.environment, execution_id)
    logger.info("=" * 70)

    s3_client = boto3.client("s3")
    quality_results_bucket = config.quality_results_bucket
    quality_results_path = (
        f"s3://{quality_results_bucket}/quality-results/"
        f"environment={config.environment}/execution_id={execution_id}/"
    )
    run_summary = {
        "execution_id": execution_id,
        "job": config.job_name,
        "pipeline": config.pipeline_name,
        "environment": config.environment,
        "execution_timestamp": execution_timestamp,
        "processing_mode": "BLOCKING",
        "inputs_read": [],
        "quality_gates": [],
        "writes": [],
        "silver_written": False,
        "pipeline_status": "RUNNING",
    }
    summary_key = f"{_key_from_uri(quality_results_path)}run_summary.json"

    try:
        # 0. config.json: entradas y salidas
        pipeline_cfg = read_json_from_s3(s3_client, *parse_s3_uri(config.pipeline_config_s3_uri))
        flow = load_and_validate_pipeline_config(
            pipeline_cfg, config.pipeline_name, platform_binding(config), SILVER_TABLES, PIPELINE_INPUT_FORMATS,
        )
        run_summary["data_flow"] = flow
        for spec in flow["inputs"].values():
            logger.info("ENTRADA %s | %s | %s", spec["name"], spec["format"], spec["location"])
        for spec in flow["outputs"].values():
            logger.info("SALIDA  %s | %s", spec["location"], spec["format"])

        glue_context, spark = build_spark_session(flow["catalog_name"], flow["warehouse"])
        _assert_session_warehouse(spark, flow)
        # business_logic.py asume UTC (process_date = fecha UTC de transaction_ts).
        spark.conf.set("spark.sql.session.timeZone", "UTC")
        job = Job(glue_context)
        # Los argumentos resueltos incluyen --job-bookmark-option y JOB_RUN_ID; con
        # solo JOB_NAME Glue desactiva el Bookmark y cada ejecución relee todo Bronze.
        job.init(config.job_name, getResolvedOptions(sys.argv, ["JOB_NAME"]))

        # 1. Lectura de entradas según format (parquet / csv)
        reads = read_inputs(spark, glue_context, flow)
        for name, (_, files) in reads.items():
            run_summary["inputs_read"].append({"input": name, "files_new": files})
        finance_raw, _ = reads[FINANCE_INPUT]
        catalogs_raw, _ = reads[CATALOGS_INPUT]

        if finance_raw is None:
            logger.info("SIN DATOS en la entrada %s. Finalizando sin cambios.", FINANCE_INPUT)
            run_summary["pipeline_status"] = "SUCCESS_NO_NEW_DATA"
            write_json_to_s3(s3_client, quality_results_bucket, summary_key, run_summary)
            job.commit()
            return
        if catalogs_raw is None:
            raise RuntimeError(f"La entrada {CATALOGS_INPUT} no tiene archivos: sin catálogos no se "
                               "puede enriquecer. Cargar los CSV en Bronze antes de ejecutar.")

        # 2. Lógica de negocio: cruce transacciones x catálogos
        run_summary["records_read"] = finance_raw.count()
        run_summary["catalog_rows_read"] = catalogs_raw.count()
        silver_dfs = build_silver_tables(finance_raw, catalogs_raw)
        for table_name, df in silver_dfs.items():
            silver_dfs[table_name] = df.cache()

        # 3. Data Quality bloqueante, por tabla
        quality_config = load_quality_config(s3_client, *parse_s3_uri(config.quality_rules_s3_uri))
        gate_results = {}
        for table_name in SILVER_TABLES:
            rules = quality_config.get(table_name, {"critical": [], "warning": []})
            result = evaluate_table_quality(
                glue_context, silver_dfs[table_name], table_name,
                rules.get("critical", []), rules.get("warning", []),
                quality_results_path,
            )
            gate_results[table_name] = result
            run_summary["quality_gates"].append(result.to_dict())
            logger.info("DQ RESULTADO | tabla=%s | status=%s | criticas_fallidas=%s | warnings_fallidos=%s",
                        table_name, result.status, len(result.critical_failed_rules), len(result.warning_failed_rules))

        blocking_tables = [name for name, r in gate_results.items() if r.is_blocking]
        if blocking_tables:
            run_summary["pipeline_status"] = "FAILED_DATA_QUALITY"
            write_json_to_s3(s3_client, quality_results_bucket, summary_key, run_summary)
            raise RuntimeError(
                f"Calidad de datos BLOQUEANTE fallida en: {blocking_tables}. "
                f"No se escribio nada en Silver en esta ejecucion. Ver detalle en "
                f"{quality_results_path}run_summary.json"
            )

        # 4. Escritura según format + verificación
        run_summary["writes"] = write_outputs(
            spark, flow, silver_dfs, {t: TABLE_DDL[t]["match_columns"] for t in SILVER_TABLES},
        )
        run_summary["silver_written"] = True
        run_summary["pipeline_status"] = "SUCCESS"
        write_json_to_s3(s3_client, quality_results_bucket, summary_key, run_summary)

        logger.info("=" * 70)
        logger.info("PIPELINE FINALIZADO CORRECTAMENTE | execution_id=%s", execution_id)
        logger.info("=" * 70)
        job.commit()

    except Exception:
        logger.exception("PIPELINE ABORTADO | execution_id=%s", execution_id)
        if run_summary["pipeline_status"] == "RUNNING":
            run_summary["pipeline_status"] = "FAILED"
        try:
            write_json_to_s3(s3_client, quality_results_bucket, summary_key, run_summary)
        except Exception:
            logger.exception("No se pudo persistir run_summary.json tras el fallo.")
        # No se llama job.commit(): el Bookmark no avanza y los archivos se
        # reintentan (el MERGE es idempotente).
        raise


def _key_from_uri(s3_uri: str) -> str:
    _, key = parse_s3_uri(s3_uri)
    return key


if __name__ == "__main__":
    main()
